const fieldModel = require('../models/fields');
const reviewModel = require('../models/review');

module.exports = {
  //for create reviews
   create: async function (req, res) {
    const { review } = req.body;
  
    const newProduct = await reviewModel.create({
      title: req.body.title,
      text: req.body.text,
      rating: req.body.rating,
      user: req.body.user,
      field: req.body.field,
      done: false,
    });
  
    await fieldModel.updateMany({ '_id': newProduct.field }, { $push: { reviews: newProduct._id } });
  
    //return res.send(newProduct);
    res.json({status: "success", message: "Review added successfully!!!", data: newProduct});
      
   },
   //for delete reviews
   deleteReview: async function (req, res) {
    const _id = req.params.id;
    const review = await reviewModel.findOne({ _id });
  
    await review.remove();
  
    await fieldModel.updateMany({ '_id': review.field }, { $pull: { reviews: review._id } });
  
   //return res.redirect(review);
    res.json({status: "success", message: "Review Deleted successfully!!!", data: review});
  },
   
  //for get by single review with id
   getById: function(req, res) {
    reviewModel.findById({ _id: req.params.id }).populate({path:'field', select:'fieldName reviews'}) .then(function(dbReview)
      { 
         //res.json(dbReview);
         res.json({status:"success", message: "Reviews found!!!", data:{reviews: dbReview}});
         }).catch(function(err) {
            res.json(err); });
  },
  //for update reviews
   updateById: async function (req, res) {

      reviewModel.findByIdAndUpdate(req.params.id, {$set: req.body}, {new: true}, function(err, dish){
          if(err) throw err;
          // res.json(dish);
          res.json({status: "success", message: "Review Updated successfully!!!", data: dish});
        });
    
      
    },
    ///for show all reviews
    getAll: function(req, res, next) {
      let reviewsList = [];
      reviewModel.find({}, function(err, reviews){
       if (err){
        next(err);
       } else{
        for (let review of reviews) {
          reviewsList.push({id: review._id, title: review.title, rating: review.rating, user: review.user, field: review.field});
        }
        res.json({status:"success", message: "All Reviews list found!!!", data:{reviews: reviewsList}});
           
       }
    });
     },
  }
  /*router.put('/review/:id', async function (req, res) {
    //return res.send(newProduct);
  
    const newProduct = await reviewModel.findByIdAndUpdate(req.params.id,
       {$set: req.body}, {new: true});
       const _id = req.params.id;
       const review = await reviewModel.findById({ _id });
     
  //await review.remove();
     
       await fieldModel.updateMany({ '_id': review.field }, { $pull: { reviews: review._id } });
  
      await fieldModel.updateMany({ '_id': newProduct.field }, { $push: { reviews: newProduct._id } });
      
       // res.json(dish);
        res.json({status: "success", message: "Review Updated successfully!!!", data: newProduct});
     
     
   
  });
  */

