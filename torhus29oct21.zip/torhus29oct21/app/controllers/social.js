'use strict';
const socialModel = require('../models/social');
const uploadIcon = async (req, res, next) => {
    try{
        const file = new socialModel({
            name: req.body.name,
            timestamp: req.body.timestamp,
            description: req.body.description,
            iconName: req.file.originalname,
            iconPath: req.file.path,
            iconType: req.file.mimetype,
            iconSize: fileSizeFormatter(req.file.size, 2) //0.00
        });
        await file.save();
       console.log(file);
        res.status(200).send('Socail icon & link added successfully.'); 
    }catch(error) {
        res.status(200).send(error.message);

    }
}
const fileSizeFormatter = (bytes, decimal) => {
    if(bytes == 0)
    {
        return '0 Bytes';
    }
    const dm = decimal || 2;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'YB', 'ZB'];
    const index = Math.floor(Math.log(bytes) / Math.log(1000));
    return parseFloat((bytes / Math.pow(1000, index)).toFixed(dm)) + ' ' + sizes[index];
}
module.exports = {
 uploadIcon,
 getById: function(req, res, next) {
  console.log(req.body);
  socialModel.findById(req.params.socialId, function(err, socialInfo){
   if (err) {
    next(err);
   } else {
    res.json({status:"success", message: "Social Icons found!!!", data:{icons: socialInfo}});
   }
  });
 },
getAll: function(req, res, next) {
  let iconsList = [];
  socialModel.find({}, function(err, icons){
   if (err){
    next(err);
   } else{
    for (let icon of icons) {
        iconsList.push({id: icon._id, name: icon.name, iconName: icon.iconName, iconPath: icon.iconPath});
    }
    res.json({status:"success", message: "Icons list found!!!", data:{icons: iconsList}});
       
   }
});
 },
updateById: function(req, res, next) {
    socialModel.findByIdAndUpdate(req.params.socialId,{name:req.body.name}, function(err, socialInfo){
if(err)
    next(err);
   else {
    res.json({status:"success", message: "Icons updated successfully!!!", data:null});
   }
  });
 },
deleteById: function(req, res, next) {
    socialModel.findByIdAndRemove(req.params.socialId, function(err, socialInfo){
   if(err)
    next(err);
   else {
    res.json({status:"success", message: "Icons deleted successfully!!!", data:null});
   }
  });
 },
}
