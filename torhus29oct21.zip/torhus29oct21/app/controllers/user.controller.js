const db = require("../models");
const User = db.user;
const Role = db.role;

exports.allAccess = async(req, res) => {
 Role.find({})
.then(function(dbProducts) {
  res.status(200).json({status:true, message: "Public Content.", data: dbProducts});
  //res.json(dbProducts);
})
.catch(function(err) {
  res.json(err);
})
};

exports.editRole = async(req, res) => {
    // Validate Request
    if(!req.body) {
      return res.status(200).send({
      message: "Please fill all required field"
    });
    }
    // Find user and update it with the request body
    Role.findByIdAndUpdate(req.params.roleId, {
      name: req.body.name
    }, {new: true})
    .then(user => {
    if(!user) {
      return res.status(200).json({status: false, message: "role not found with id " + req.params.roleId });

    }
    res.send(user);
    }).catch(err => {
    if(err.kind === 'ObjectId') {
      return res.status(200).json({status: false, message: "role not found with id " + req.params.roleId });
    }
    return res.status(200).send({
      message: "Error updating role with id " + req.params.roleId
    });
    });
};
exports.userBoard = (req, res) => {
  res.status(200).send("User Content.");
};

exports.adminBoard = (req, res) => {
  res.status(200).send("Admin Content.");
};

exports.moderatorBoard = (req, res) => {
  res.status(200).send("Moderator Content.");
};