const config = require("../config/auth.config");
const db = require("../models");
const User = db.user;
const Role = db.role;
const mailgun = require("mailgun-js");
const DOMAIN = 'sandbox3cc2e8c76ce4482dbb63cf311ce30056.mailgun.org';
const mg = mailgun({apiKey: process.env.MAILGUN_APIKEY, domain: DOMAIN});

var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");

exports.signup = (req, res) => {
  const user = new User({
    fullname: req.body.fullname,
    username: req.body.username,
    phoneNo: req.body.phoneNo,
    email: req.body.email,
    password: bcrypt.hashSync(req.body.password, 8)
  });

  user.save((err, user) => {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }

    if (req.body.roles) {
      Role.find(
        {
          name: { $in: req.body.roles }
        },
        (err, roles) => {
          if (err) {
            res.status(500).send({ message: err });
            return;
          }

          user.roles = roles.map(role => role._id);
          user.save(err => {
            if (err) {
              res.status(500).send({ message: err });
              return;
            }
            const {name, email, password} = req.body;
            console.log(req.body.email);
            //var token = jwt.sign({ id: user.id }, config.secret, {expiresIn: 86400 // 24 hours  });
            const token = jwt.sign({name,email,password}, process.env.JWT_ACC_ACTIVATE, {expiresIn: 86400});
            const data = {
              from: 'noreply@hello.com',
              to: req.body.email,
              subject: 'Account Activation Link!!',
              html: '<h2>Please click on given link to activate your account</h2><p>${process.env.CLIENT_URL}/authentication/activate${token}</p>'
            };
            mg.messages().send(data, function (error, body) {
              if(error){
                return res.json({
                  error: error.message
                });
              }
              return res.json({message: "Email has been sent, kindly activate your account."});
             // console.log(body);
            });
            res.send({ message: "User was registered successfully!" });
            
          });
        }
      );
    } else {
      Role.findOne({ name: "user" }, (err, role) => {
        if (err) {
          res.status(500).send({ message: err });
          return;
        }

        user.roles = [role._id];
        user.save(err => {
          if (err) {
            res.status(500).send({ message: err });
            return;
          }

          res.send({ message: "User was registered successfully!" });
        });
      });
    }
  });
};
exports.activateAccount = (req, res) =>{
  const {token} = req.body;
  if(token){
    jwt.verify(token, process.env.JWT_ACC_ACTIVATE, function(err, decodedToken){
      if(err){
        return res.status(200).json({error:"d"});
      }
    });
  }else{
    return res.json({error: "Something went wwrong!!!"});
  }

};
exports.signin = (req, res) => {
  User.findOne({
    username: req.body.username
  })
    .populate("roles", "-__v")
    .exec((err, user) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }

      if (!user) {
        return res.status(404).send({ message: "User Not found." });
      }

      var passwordIsValid = bcrypt.compareSync(
        req.body.password,
        user.password
      );

      if (!passwordIsValid) {
        return res.status(401).send({
          accessToken: null,
          message: "Invalid Password!"
        });
      }

      var token = jwt.sign({ id: user.id }, config.secret, {
        expiresIn: 86400 // 24 hours
      });

      var authorities = [];

      for (let i = 0; i < user.roles.length; i++) {
        authorities.push("ROLE_" + user.roles[i].name.toUpperCase());
      }
      res.status(200).send({
        id: user._id,
        fullname: user.fullname,
        username: user.username,
        phoneNo: user.phoneNo,
        email: user.email,
        roles: authorities,
        accessToken: token
      });
    });
};
exports.getAllUser = (req, res, next) => {
  let userList = [];
  User.find({}, function(err, users){
  if (err){
    res.status(200).json({status: false });
  } else{
    for (let user of users) {
      userList.push({id: user._id, fullname: user.fullname, username: user.username, phoneNo: user.phoneNo, email: user.email, roles: user.roles});
    }
    res.status(200).json({status:"true", message: "All Users found!!!", data: userList});
      
  }
});
}; 