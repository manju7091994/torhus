const db = require("../models");
const bookingModel = db.bookingSlot;
    module.exports = {
      // Retrieve a single Category with id
    findOne: function(req, res, next) {
      const id = req.params.bookingSlotId;
    
      bookingModel.findById(id)
        .then(data => {
          if (!data)
            res.status(200).send({ message: "Not found booking slots with id " + id });
          else 
          res.json({status:"success", message: "Booking slots found!!!", data});
        })
        .catch(err => {
          res
            .status(200)
            .send({ message: "Error retrieving booking slots with id=" + id });
        });
    },
     // Retrieve all Category
    getAll: function(req, res, next) {
        
      let bookingslotList = [];
      bookingModel.find({}, function(err, bookingslots){
       if (err){
        next(err);
       } else{
        for (let bookingslot of bookingslots) {
            bookingslotList.push({id: bookingslot._id, name: bookingslot.name});
        }
        res.json({status:"success", message: "Booking slots list found!!!", data:{bookingslots: bookingslotList}});
           
       }
    });
     },
     // Delete  Category with id
     deleteById: function(req, res, next) {
      const id = req.params.bookingSlotId;
      bookingModel.findByIdAndRemove(id)
        .then(data => {
          if (!data) {
            res.status(200).json({status: false,  message: 'Cannot delete booking slots with id='+id+'. Maybe Category was not found!'});
          
          } else {
            res.status(200).json({status:"true", message: "Booking slots deleted successfully!!!"});
          }
        })
        .catch(err => {
          res.status(200).json({status: false,  message: "Could not delete booking slots with id=" + id});
         
        });
    },
    
    // // Create and Save a Slott
    create: function(req, res, next) {
       // Validate request
       if (!req.body.name || !req.body.start_time || !req.body.end_time || !req.body.days|| !req.body.regularRate || !req.body.promotionalOffer) {
        res.status(200).json({status: false, message: "Content can not be empty!"});
        return;
      }
  
      const newBooking = new bookingModel({
        name: req.body.name,
          start_time: req.body.start_time,
          end_time: req.body.end_time,
          days: req.body.days,
          regularRate: req.body.regularRate,
          promotionalOffer: req.body.promotionalOffer
      });
      
     // Save newBooking in the database
          newBooking
          .save(newBooking)
          .then(data => {
            // res.send(data);
            res.status(200).json({status:"true", message: "Booking slots added successfully!!", data: data});
          })
          .catch(err => {
            res.status(200).send({status:"false", message: "Failed! Selected Days is already in use!"});
          });
    },
     // Update a Category identified by the id in the request
     updateById: function(req, res, next) {
        // Validate Request
        if(!req.body) {
          return res.status(400).send({
          message: "Please fill all required field"
        });
        }
        // Find user and update it with the request body
        bookingModel.findByIdAndUpdate(req.params.bookingSlotId, {
          name: req.body.name,
          start_time: req.body.start_time,
          end_time: req.body.end_time,
          days: req.body.days,
          regularRate: req.body.regularRate,
          promotionalOffer: req.body.promotionalOffer
        }, {new: true})
        .then(user => {
         if(!user) {
          return res.status(200).json({status: false, message: "user not found with id " + req.params.bookingSlotId });
    
        }
        res.send(user);
        }).catch(err => {
        if(err.kind === 'ObjectId') {
          return res.status(200).json({status: false, message: "user not found with id " + req.params.bookingSlotId });
        }
        return res.status(200).send({
          message: "Error updating user with id " + req.body.name
        });
        });
        },
    // Delete All a Category with id
        deleteAll: function(req, res, next) {
            bookingModel.deleteMany({})
            .then(data => {
              res.send({
                message:  +data.deletedCount+' Booking slots were deleted successfully!'
              });
            })
            .catch(err => {
              res.status(200).send({
                message:
                  err.message || "Some error occurred while removing all booking slots."
              });
            });
        },
    }