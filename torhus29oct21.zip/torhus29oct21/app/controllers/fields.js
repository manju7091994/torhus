const fieldModel = require('../models/fields');
const facilitiesModel = require('../models/facilities');
const multipleFileModel = require('../models/multiplefile');
const Type = require('../models/fieldCategory');
var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");

exports.createField = async (req, res) => {

     // Validate request
     if (!req.body.fieldName || !req.body.fieldAddress ||!req.body.seats || !req.body.fieldsArea_width || !req.body.fieldsArea_length || !req.body.facilitiesID ||!req.body.author || !req.body.fieldTypes) {
      res.status(200).json({status: false, message: "Content can not be empty!"});
      return;
    }
    const { fields } = req.body;
    const newFields = await fieldModel.create({
      fieldName: req.body.fieldName,
      fieldDescription: req.body.fieldDescription,
      fieldAddress: req.body.fieldAddress,
      seats: req.body.seats,
      fieldsArea_width: req.body.fieldsArea_width,
      fieldsArea_length: req.body.fieldsArea_length,
      facilitiesID: req.body.facilitiesID,
      author: req.body.author,
      fieldTypes: req.body.fieldTypes,
      reviews: req.body.reviews,
      amneties: req.body.amneties,
      socialIcon: req.body.socialIcon
    });
  
    await facilitiesModel.updateMany({ '_id': newFields.facilitiesID }, { $push: { fieldsId: newFields._id } });
  
    //return res.send(newFacilities);
    res.json({status: "success", message: "Fields added successfully!!!", data: newFields});
      
   };

//for multiple file upload
exports.multipleFileUpload = async (req, res, next) => {
  try{

    let filesArray = [];
    req.files.forEach(element => {
      const file = {
        fileName: element.originalname,
        filePath: element.path,
        fileType: element.mimetype,
        fileSize: fileSizeFormatter(element.size, 2) //0.00
      }  
        filesArray.push(file);
    });
    const multipleFiles = new multipleFileModel({
      title: req.body.title,
      files: filesArray

    });
    console.log(multipleFiles);
    await multipleFiles.save();
    
    res.status(200).send('Files uploaded successfully');
  }catch(error){
    res.status(200).send(error.message);
  }
};

exports.getAllMultipleFiles = async (req, res, next) => {
  try{
      const files = await multipleFileModel.find();
      res.status(200).send(files);
  }catch(error){
    res.status(200).send(error.message);

  }
};

const fileSizeFormatter = (bytes, decimal) => {
  if(bytes == 0)
  {
      return '0 Bytes';
  }
  const dm = decimal || 2;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'YB', 'ZB'];
  const index = Math.floor(Math.log(bytes) / Math.log(1000));
  return parseFloat((bytes / Math.pow(1000, index)).toFixed(dm)) + ' ' + sizes[index];
}

   //for delete fields
   exports.deleteById = async (req, res) => {
    const _id = req.params.fieldId;
    const field = await fieldModel.findOne({ _id });
    if (!field)
    res.status(200).json({status:"false", message: "Not found facilities with id = " + _id });
    else{
      await field.remove();
  
      await facilitiesModel.updateMany({ '_id': field.facilitiesID }, { $pull: { fieldsId: field._id } });
    
        res.status(200).json({status:"true", message: "field deleted successfully!!!"});
      
    }
   
  };
 exports.getById = (req, res) => {
  console.log(req.body);
  fieldModel.findById(req.params.fieldId, function(err, facilityInfo){
   if (err) {
    next(err);
   } else {
    res.json({status:"success", message: "Amneties found!!!", data:{fields: facilityInfo}});
   }
  });
 };
 exports.getReview = (req, res) => {
  fieldModel.findById({ _id: req.params.fieldId }).populate({path:'reviews', select:'title'}) .then(function(dbReview)
  { 
     //res.json(dbReview);
     res.json({status:"success", message: "All Reviews found!!!", data:{reviews: dbReview}});
     }).catch(function(err) {
        res.json(err); });
 };
 exports.getAll = (req, res) => {
  let fieldList = [];
  fieldModel.find({}, function(err, fields){
   if (err){
    next(err);
   } else{
    for (let field of fields) {
      fieldList.push({id: field._id, fieldName: field.fieldName, fieldDescription: field.fieldDescription, facilitiesID: field.facilitiesID});
    }
    res.json({status:"success", message: "Fields list found!!!", data:{fields: fieldList}});
       
   }
});
 };
 //for update fields
  exports.updateById = async (req, res) => {
    const id = req.params.fieldId;
    facilitiesModel.updateMany({ $pull: { fieldsId: req.params.fieldId } });
   const newFields = await fieldModel.findByIdAndUpdate(id, {$set: req.body}, {new: true});
    if (!newFields)
    res.status(200).json({status:"false", message: "Not found fields with id = " + id });
    else
     
    await facilitiesModel.updateMany({ '_id': newFields.facilitiesID }, { $pull: { fieldsId: newFields._id } });
    
    await facilitiesModel.updateMany({ '_id': newFields.facilitiesID }, { $push: { fieldsId: newFields._id } });
    res.json({status: "success", message: "Field Updated successfully!!!", data: newFields});
  // This will also populate category along with product

};

 ///for get all data
 /*router.get("/", function(req,res) {
  fieldModel.find({})
.then(function(dbProducts) {
  res.json(dbProducts);
})
.catch(function(err) {
  res.json(err);
})
});*/
