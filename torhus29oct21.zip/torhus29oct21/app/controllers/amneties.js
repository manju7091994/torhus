'use strict';
const amnetiesModel = require('../models/amneties');
const singleFileUpload = async (req, res, next) => {
    try{
        const file = new amnetiesModel({
            name: req.body.name,
            description: req.body.description,
            fileName: req.file.originalname,
            filePath: req.file.path,
            fileType: req.file.mimetype,
            fileSize: fileSizeFormatter(req.file.size, 2) //0.00
        });
        await file.save();
       console.log(file);
       res.status(200).json({ status: "True", message: "Amneties added successfully!!!", data: file});
    }catch(error) {
        //res.status(400).send(error.message);
        res.status(200).json({ status: "False" });
    }
}
const fileSizeFormatter = (bytes, decimal) => {
    if(bytes == 0)
    {
        return '0 Bytes';
    }
    const dm = decimal || 2;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'YB', 'ZB'];
    const index = Math.floor(Math.log(bytes) / Math.log(1000));
    return parseFloat((bytes / Math.pow(1000, index)).toFixed(dm)) + ' ' + sizes[index];
}
module.exports = {
singleFileUpload,
getById: function(req, res, next) {
  console.log(req.body);
 const id = req.params.amnnetiesId;
  amnetiesModel.findById(id)
  .then(data => {
    if (!data)
    res.status(200).json({status:"false", message: "Not found Amneties with id = " + id });
    else 
    res.status(200).json({status:"true", message: "Amneties found!!!", data});
  })
  .catch(err => {
    res.status(200).json({status:"false", message: "Error retrieving Amneties with id= " + id });
  });
 },
getAll: function(req, res, next) {
    let amnetiesList = [];
    amnetiesModel.find({}, function(err, amneties){
        if (err){
            res.status(200).json({ status: "false" });
        } else{
            for (let amnety of amneties) {
                amnetiesList.push({id: amnety._id, name: amnety.name, fileName: amnety.fileName, filePath: amnety.filePath});
            }
            res.status(200).json({ status: "true", message: "Amneties list found!!!", data:{amneties: amnetiesList} });

        }
    });
 },

 updateById: function(req, res, next) {
    // Validate Request
    if(!req.body) {
      return res.status(400).send({
      message: "Please fill all required field"
    });
    }
    // Find amneties and update it with the request body
    amnetiesModel.findByIdAndUpdate(req.params.amnnetiesId, {
            name: req.body.name,
            description: req.body.description,
            fileName: req.file.originalname,
            filePath: req.file.path,
            fileType: req.file.mimetype,
            fileSize: fileSizeFormatter(req.file.size, 2) //0.00
    }, {new: true})
    .then(user => {
     if(!user) {
      return res.status(200).json({status: false, message: "Amneties not found with id " + req.params.amnnetiesId });

    }
    res.status(200).json({status: true, message: "Amneties updated with id " + req.params.amnnetiesId, data: user });
    }).catch(err => {
    if(err.kind === 'ObjectId') {
      return res.status(200).json({status: false, message: "Amneties not found with id " + req.params.amnnetiesId });
    }
    return res.status(200).send({
      message: "Error updating amneties with id " + req.params.amnnetiesId
    });
    });
    },
 
deleteById: function(req, res, next) {
    const id = req.params.amnnetiesId;
    amnetiesModel.findByIdAndRemove(id) .then(data => {
        if (!data) {
            res.status(200).json({ status: "false",  message: "Cannot delete Amneties with id="+id+". Maybe Amneties was not found!"});
         
        } else {
            res.status(200).json({ status: "true", message: "Amneties deleted.."});
        }
      })
      .catch(err => {
        res.status(200).json({ status: "false", message: "Could not delete Amneties with id=" + id });
        
      });
 },
}
