const facilityModel = require('../models/facilities');
const fieldsModel = require('../models/fields');
const db = require("../models");
const User = db.user;

module.exports = {
  getById: function(req, res, next) {
    console.log(req.body);
    const id = req.params.facilityId;
    facilityModel.findById(id).then(data => {
      if (!data)
      res.status(200).json({status:"false", message: "Not found facilities with id = " + id });
      else 
      res.status(200).json({status:"true", message: "Facilities found!!!", data: data});
    })
    .catch(err => {
      res.status(200).json({status:"false", message: "Error retrieving facilities with id= " + id });
    });
  },
  getAll: function(req, res, next) {
    let facilitiesList = [];
    facilityModel.find({}, function(err, facilities){
    if (err){
      res.status(200).json({status: false });
    } else{
      for (let facility of facilities) {
        facilitiesList.push({id: facility._id, facilities_name: facility.facilities_name, facilities_details: facility.facilities_details, description: facility.description, released_on: facility.released_on});
      }
      res.status(200).json({status:"true", message: "All Facilities found!!!", data: facilitiesList});
        
    }
  });
  }, 
  //for update facility
  updateById: async function (req, res) {
      const id = req.params.facilityId;
      facilityModel.findByIdAndUpdate(id, {$set: req.body}, {new: true}).then(data => {
        if (!data)
        res.status(200).json({status:"false", message: "Not found facilities with id = " + id });
        else 
        res.status(200).json({status:"true", message: "Facilities updated!!!", data: data});
      })
      .catch(err => {
        res.status(200).json({status:"false", message: "Error retrieving facilities with id= " + id });
      });
      
    
      
  },
  //for delete facility
  deleteById: async function (req, res) {
    const _id = req.params.facilityId;
    const facility = await facilityModel.findOne({ _id });
    if (!facility)
    res.status(200).json({status:"false", message: "Not found facilities with id = " + _id });
    else{
        await facility.remove();
        await User.updateMany({ '_id': facility.author }, { $pull: { facilitiesId: facility._id } });
        await fieldsModel.updateMany({ '_id': facility.fieldsId }, { $pull: { facilitiesID: facility._id } });
        res.status(200).json({status:"true", message: "Facilities deleted!!!"});
      
    }
   
  },
  //for create new facility
  add: async function (req, res) {
       // Validate request
       if (!req.body.facilities_name) {
        res.status(200).json({status: false, message: "Content can not be empty!"});
        return;
      }
    const { facility } = req.body;
    try{
      const newFacilities = await facilityModel.create({
        facilities_name: req.body.facilities_name,
        facilities_details: req.body.facilities_details,
        description: req.body.description,
        author: req.body.author
      });

      await User.updateMany({ '_id': newFacilities.author }, { $push: { facilitiesId: newFacilities._id } });

      //return res.send(newFacilities);
      return res.status(200).json({ status: "true", message: "Facilities added successfully!!", data: newFacilities });
      }
    catch(error) {
        //res.status(400).send(error.message);
        res.status(200).json({ status: "false", message:"Facility validation failed" });
    }
  },
  //show all fields by facility
  getFields: async function (req, res) {
    const _id = req.params.facilityId ;
  facilityModel.findById({ _id }).populate({path:'fieldsId', select:'fieldName fieldAddress seats fieldTypes author'}) .then(function(dbFields)
  { 
    if (!dbFields){
      res.status(200).json({status:"false", message: "Not found facilities with id = " + _id });
    }else{
      res.status(200).json({status:"true", message: "All Fields found in this facility!!!", data:{fields: dbFields}});
    }
     }).catch(function(err) {
      res.status(200).json({status:"false", message: "Error retrieving facilities with id= " + _id });});
  },
      // Delete All a Category with id
      deleteAll: function(req, res, next) {
        facilityModel.deleteMany({})
        .then(data => {
          res.send({
            message:  +data.deletedCount+' Facility were deleted successfully!'
          });
        })
        .catch(err => {
          res.status(200).send({
            message:
              err.message || "Some error occurred while removing all facilitiess."
          });
        });
    },
}