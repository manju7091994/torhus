const categoryModel = require('../models/fieldCategory');
module.exports = {
  // Retrieve a single Category with id
findOne: function(req, res, next) {
  const id = req.params.categoryId;

  categoryModel.findById(id)
    .then(data => {
      if (!data)
        res.status(200).send({ message: "Not found Category with id " + id });
      else 
      res.json({status:"success", message: "Category found!!!", data});
    })
    .catch(err => {
      res
        .status(200)
        .send({ message: "Error retrieving Category with id=" + id });
    });
},
 // Retrieve all Category
getAll: function(req, res, next) {
  let categoriesList = [];
  categoryModel.find({}, function(err, fieldCategories){
   if (err){
    next(err);
   } else{
    for (let fieldCategory of fieldCategories) {
        categoriesList.push({id: fieldCategory._id, name: fieldCategory.name});
    }
    res.json({status:"success", message: "Category list found!!!", data:{fieldCategories: categoriesList}});
       
   }
});
 },
 // Delete  Category with id
 deleteById: function(req, res, next) {
  const id = req.params.categoryId;
  categoryModel.findByIdAndRemove(id)
    .then(data => {
      if (!data) {
        res.status(200).json({status: false,  message: 'Cannot delete Category with id=${id}. Maybe Category was not found!'});
      
      } else {
        res.status(200).json({status:"true", message: "Category deleted successfully!!!"});
      }
    })
    .catch(err => {
      res.status(200).json({status: false,  message: "Could not delete Category with id=" + id});
     
    });
},
// // Create and Save a new Category
 create: function(req, res, next) {
  // Validate request
  if (!req.body.name) {
    res.status(200).json({status: false, message: "Content can not be empty!"});
    return;
  }

  // Create a Categoory
  const category = new categoryModel({
    name: req.body.name,
    published: req.body.published ? req.body.published : true
  });

  // Save category in the database
  category
    .save(category)
    .then(data => {
     // res.send(data);
      res.status(200).json({status:"true", message: "Category added successfully!!", data: data});
    })
    .catch(err => {
      res.status(200).send({
        message:
          err.message || "Some error occurred while creating the category."
      });
    });
},
 // Update a Category identified by the id in the request
 updateById: function(req, res, next) {
    // Validate Request
    if(!req.body) {
      return res.status(400).send({
      message: "Please fill all required field"
    });
    }
    // Find user and update it with the request body
    categoryModel.findByIdAndUpdate(req.params.categoryId, {
      name: req.body.name
    }, {new: true})
    .then(user => {
     if(!user) {
      return res.status(200).json({status: false, message: "user not found with id " + req.params.categoryId });

    }
    res.send(user);
    }).catch(err => {
    if(err.kind === 'ObjectId') {
      return res.status(200).json({status: false, message: "user not found with id " + req.params.categoryId });
    }
    return res.status(200).send({
      message: "Error updating user with id " + req.params.categoryId
    });
    });
    },
// Delete All a Category with id
    deleteAll: function(req, res, next) {
      categoryModel.deleteMany({})
        .then(data => {
          res.send({
            message: '${data.deletedCount} Categories were deleted successfully!'
          });
        })
        .catch(err => {
          res.status(200).send({
            message:
              err.message || "Some error occurred while removing all categories."
          });
        });
    },
}