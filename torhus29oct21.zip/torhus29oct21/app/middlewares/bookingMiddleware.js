
const db = require("../models");
require('dotenv'). config();
const Book = db.bookingSlot;

checkDuplicateDays = (req, res, next) => {
  // Username
  const {name, start_time, end_time, days, regularRate, promotionalOffer} = req.body;
    
  Book.findOne({
    name: req.body.name
  }).exec((err, user) => {
    if (err) {
      res.status(200).send({ message: err });
      return;
    }

    if (user) {
      res.status(200).send({ message: "Failed! Name is already in use!" });
      return;
    }

    // Email
    Book.findOne({
      days: req.body.days
    }).exec((err, user) => {
      if (err) {
        res.status(200).send({ message: err });
        return;
      }

      if (user) {
        res.status(200).send({ message: "Failed! Selected Days is already in use!" });
        return;
      }
   

      next();
    });
  });
};



const bookingMiddleware = {
    checkDuplicateDays
};

module.exports = bookingMiddleware;