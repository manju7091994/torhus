const { bookingMiddleware } = require("../middlewares");
const controller = require("../controllers/bookingSlot");



// Retrieve all Slots
module.exports = function(app) {
    app.use(function(req, res, next) {
      res.header(
        "Access-Control-Allow-Headers",
        "x-access-token, Origin, Content-Type, Accept"
      );
      next();
    });
    var slots = [bookingMiddleware.checkDuplicateDays]
    app.post("/api/v1.0/bookingSlot", slots, controller.create);
    app.get('/api/v1.0/bookingSlot', controller.getAll);
    // Retrieve a single Slots with id
    app.get('/api/v1.0/bookingSlot/:bookingSlotId', controller.findOne);
    // Update a Slots with id
    app.put('/api/v1.0/bookingSlot/:bookingSlotId', controller.updateById);
    // Delete a Slots with id
    app.delete('/api/v1.0/bookingSlot/:bookingSlotId', controller.deleteById);
    // Delete all Slots with id
    app.delete('/api/v1.0/bookingSlot', controller.deleteAll);
  
  };