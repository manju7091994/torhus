'use strict';
const express = require('express');
const {upload} = require('../helpers/filehelper');
const router = express.Router();
const amnetiesController = require('../controllers/amneties');
var multer = require('multer');

//Create new amneties
router.post('/amneties', upload.single('file'), amnetiesController.singleFileUpload);//for single
// Retrieve all icons
router.get('/amneties', amnetiesController.getAll);
// Retrieve a single amneties with id
router.get('/amneties/:amnnetiesId', amnetiesController.getById);
// Update a amneties with id
router.put('/amneties/:amnnetiesId', upload.single('file'), amnetiesController.updateById);
// Delete a amneties with id
router.delete('/amneties/:amnnetiesId', amnetiesController.deleteById);
module.exports = {
  routes: router
} 

