const express = require('express');
const router = express.Router();
const category = require('../controllers/fieldCategory');

// Retrieve all Category
router.get('/fieldCategory', category.getAll);
// Create a new Category
router.post('/fieldCategory', category.create);
// Retrieve a single Category with id
router.get('/fieldCategory/:categoryId', category.findOne);
// Update a Category with id
router.put('/fieldCategory/:categoryId', category.updateById);
// Delete a Category with id
router.delete('/fieldCategory/:categoryId', category.deleteById);
// Delete all Category with id
router.delete('/fieldCategory', category.deleteAll);
module.exports = router;