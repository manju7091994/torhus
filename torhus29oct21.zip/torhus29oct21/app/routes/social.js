'use strict';
const express = require('express');
const {upload} = require('../helpers/filehelper');
const router = express.Router();
const icon = require('../controllers/social');
var multer = require('multer');

// Create a new icon
router.post('/socialIcon', upload.single('file'), icon.uploadIcon);//for single
// Retrieve all icons
router.get('/socialIcon', icon.getAll);
// Retrieve a single icon with id
router.get('/socialIcon/:socialId', icon.getById);
// Update a icon with id
router.put('/socialIcon/:socialId', icon.updateById);
// Delete a icon with id
router.delete('/socialIcon/:socialId', icon.deleteById);
module.exports = {
  routes: router
} 

