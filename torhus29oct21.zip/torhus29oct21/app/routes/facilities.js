const express = require('express');
const router = express.Router();

const facility = require('../controllers/facilities');
//get all facility
router.get('/facilities', facility.getAll);
//create new facility
router.post('/facilities', facility.add);
//get new facility by id
router.get('/facilities/:facilityId', facility.getById);
//update new facility by id
router.put('/facilities/:facilityId', facility.updateById);
//delete new facility by id
router.delete('/facilities/:facilityId', facility.deleteById);
//get all fields in particular facility
router.get("/facilities/:facilityId/fields", facility.getFields);
router.delete("/facilities", facility.deleteAll);
module.exports = router;