'use strict';
const express = require('express');
const app = express();
const fields = require("../controllers/fields");
const {upload} = require('../helpers/filehelper');
var multer = require('multer');
const router = express.Router();


//router.post('/', fields.field);
router.post('/fields', fields.createField);
//post for multiple images
router.post('/fields/multipleFiles', upload.array('files'), fields.multipleFileUpload);
router.get('/fields/multipleFiles', fields.getAllMultipleFiles);
router.delete('/fields/:fieldId', fields.deleteById);
router.get('/fields', fields.getAll);
router.get('/fields/:fieldId', fields.getById);
router.get("/fields/:fieldId/reviews", fields.getReview);
router.put('/fields/:fieldId', fields.updateById);
module.exports = router;