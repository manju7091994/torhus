const express = require('express');
const Reviews  = require('../controllers/review');
const fieldModel = require('../models/fields');
const reviewModel = require('../models/review');
const router = express.Router();

// Create a new Review
router.post('/review', Reviews.create);
router.delete('/review/:id', Reviews.deleteReview);
router.put('/review/:id', Reviews.updateById);
router.get("/review", Reviews.getAll);
router.get("/review/:id", Reviews.getById);
module.exports = {
  routes: router
} 

