const mongoose = require("mongoose");
const Field = mongoose.model(
  "Field",
  new mongoose.Schema({
    fieldName: {
      type: String,
      required: true,
      max: 100
  },
  fieldDescription: {
    type: String,
    trim: true
  },
  fieldAddress: {
    type: String,
    trim: true,
    required: true
  },
  seats: {
    type: Number,
    trim: true,
    required: true
  },
  fieldsArea_width: {
    type: String,
    trim: true,
    required: true
  },
  fieldsArea_length: {
    type: String,
    trim: true,
    required: true
  },
  facilitiesID:[
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Facility",
      required: true
    }
  ],
  author:
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },
  fieldTypes: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "FieldCategory",
      required: true
    }
  ],
  reviews: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Review'
  }],
  amneties: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Amneties"
    }
  ],
  socialIcon: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Social"
    }
  ],
  bookingSlots: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "BookingSlot"
    }
  ]
  }, {timestamps: true})
);

module.exports = Field;