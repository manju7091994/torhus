const mongoose = require("mongoose");

const User = mongoose.model(
  "User",
  new mongoose.Schema({
    fullname: {
      type: String,
      required: 'Full Name is required',
      max: 100
  },
    username: {
      type: String,
      unique: true,
      required: 'Your username is required',
  },  
phoneNo: {
    type: String,
    required: true,
},
  verified: {
    type: Boolean,
    default: false,
},
    email: {
    type: String,
    unique: true,
    required: 'Your email is required',
    trim: true
  },
    password: {
      type: String,
      required: 'Your password is required',
      max: 100
  },
    roles: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Role",
        required: 'Your role is required',
      }
    ],
    facilitiesId:  [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Facility"
      }
    ]
  }, {timestamps: true})
);

module.exports = User;