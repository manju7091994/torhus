const mongoose = require("mongoose");

var fieldCategorySchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        max: 100
    },
    published: Boolean
}, {timestamps: true});
module.exports = mongoose.model("FieldCategory", fieldCategorySchema);