const mongoose = require("mongoose");

const Facility = mongoose.model(
  "Facility",
  new mongoose.Schema({
    facilities_name: {
      type: String,
      trim: true,
      required: true
     },
     facilities_details: {
      type: String,
      trim: true
     },
     description: {
        type: String,
        trim: true,
        required: true
     },
     author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    fieldsId: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Field'
    }]
  }, {timestamps: true})
);

module.exports = Facility;