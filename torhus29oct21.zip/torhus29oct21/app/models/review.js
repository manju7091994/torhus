const mongoose = require("mongoose");
var reviewSchema = new mongoose.Schema({
    title: {
        type: String,
        trim: true,
        required: true,
        maxlength:100
    },
    text: {
      type: String,
        required: true
    }, 
    rating: {
      type: Number,
      min: 1,
      max: 10,
      required: true
    },
    likes: {
      type: Number,
      default: 0
    },
    comments:[{
      type: String
    }],
    user:
        {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
          required: true
        },
    field: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Field',
      required: true
  }
}, {timestamps: true});
module.exports = mongoose.model("Review", reviewSchema);
