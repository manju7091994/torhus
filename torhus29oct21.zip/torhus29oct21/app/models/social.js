var mongoose = require('mongoose');

var Schema = mongoose.Schema;
var socialSchema = new mongoose.Schema({
  name: { type: String, lowercase: true , unique: true, required: true },
  description: { type: String},
  iconName: { type: String, required: true },
  iconPath: { type: String, required: true },
  iconType: { type: String, required: true },
  iconSize: { type: String, required: true },
  timestamp: { type : Date, default: Date.now },
  is_deleted:  { type: Boolean, default: false }
});
module.exports = mongoose.model("Social", socialSchema);
