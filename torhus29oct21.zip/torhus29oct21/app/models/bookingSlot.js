const mongoose = require("mongoose");
var bookingSlotSchema = new mongoose.Schema({
    name: { 
    type: String,
    lowercase: true ,
    unique:true,
    required: 'required name'
    },
    start_time: {
      type: String,
        required: true
    }, 
    end_time: {
        type: String,
        required: true
    },
    days: [{
        type: String,
        unique: true,
        required: 'required days'
    }],
    regularRate:{
      type: Number,
      required: true
    },
    promotionalOffer:{
        type: Number,
        required: true
      }
}, {timestamps: true});
module.exports = mongoose.model("BookingSlot", bookingSlotSchema);
