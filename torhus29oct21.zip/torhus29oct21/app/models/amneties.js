const mongoose = require("mongoose");
var amnetiesSchema = new mongoose.Schema({
    name: {
        type: String, lowercase: true , required: true
    },
    description: {
        type: String
    },
    fileName: {
        type: String,
        required: true
    },
    filePath: {
        type: String,
        required: true
    },
    fileType: {
        type: String,
        required: true
    },
    fileSize: {
        type: String,
        required: true
    }
}, {timestamps: true});
module.exports = mongoose.model("Amneties", amnetiesSchema);
