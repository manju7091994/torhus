const express = require('express');
const router = express.Router();
const fieldCategoryController = require('../controllers/fieldCategory');
router.get('/', fieldCategoryController.getAll);
router.post('/add', fieldCategoryController.add);
router.get('/:categoryId', fieldCategoryController.getById);
router.put('/:categoryId', fieldCategoryController.updateById);
router.delete('/:categoryId', fieldCategoryController.deleteById);
module.exports = router;