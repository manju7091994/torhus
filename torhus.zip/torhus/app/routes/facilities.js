const express = require('express');
const router = express.Router();
const facilityController = require('../controllers/facilities');
router.get('/', facilityController.getAll);
router.post('/', facilityController.create);
router.get('/:facilityId', facilityController.getById);
router.put('/:facilityId', facilityController.updateById);
router.delete('/:facilityId', facilityController.deleteById);
module.exports = router;