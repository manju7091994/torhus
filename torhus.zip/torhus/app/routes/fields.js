const express = require('express');
const router = express.Router();
const fieldsController = require("../controllers/fields");
router.post('/', fieldsController.field);
router.delete('/:fieldId', fieldsController.deleteById);
router.get('/', fieldsController.getAll);
module.exports = router;