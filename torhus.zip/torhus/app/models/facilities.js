const mongoose = require("mongoose");

const Facility = mongoose.model(
  "Facility",
  new mongoose.Schema({
    facilities_name: {
      type: String,
      trim: true,  
      required: true
     },
     facilities_details: {
      type: String,
      trim: true
     },
     description: {
        type: String,
        trim: true
     },
    released_on: {
      type: Date,
      trim: true
     }
  })
);

module.exports = Facility;