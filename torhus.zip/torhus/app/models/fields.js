const mongoose = require("mongoose");
const Field = mongoose.model(
  "Field",
  new mongoose.Schema({
    fieldName: {
      type: String,
      required: 'Field is required',
      max: 100
  },
  fieldDescription: {
    type: String,
    trim: true
  },
  fieldReleased_on: {
    type: Date,
    trim: true,
    required: true
   },
   roles: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Facility",
      required: 'Your role is required',
    }
  ]
  })
);

module.exports = Field;