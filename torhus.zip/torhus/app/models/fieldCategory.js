const mongoose = require("mongoose");

var fieldCategorySchema = new mongoose.Schema({
    name: {
        type: String,
        required: 'Name is required || Please enter name!!',
        max: 100
    }
});

module.exports = mongoose.model("FieldCategory", fieldCategorySchema);