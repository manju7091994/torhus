const categoryModel = require('../models/fieldCategory');
module.exports = {
 getById: function(req, res, next) {
  console.log(req.body);
  categoryModel.findById(req.params.categoryId, function(err, categoryInfo){
   if (err) {
    next(err);
   } else {
    res.json({status:"success", message: "Category found!!!", data:{fieldCategories: categoryInfo}});
   }
  });
 },
getAll: function(req, res, next) {
  let categoriesList = [];
  categoryModel.find({}, function(err, fieldCategories){
   if (err){
    next(err);
   } else{
    for (let fieldCategory of fieldCategories) {
        categoriesList.push({id: fieldCategory._id, name: fieldCategory.name});
    }
    res.json({status:"success", message: "Category list found!!!", data:{fieldCategories: categoriesList}});
       
   }
});
 },
updateById: function(req, res, next) {
    categoryModel.findByIdAndUpdate(req.params.categoryId,{name:req.body.name}, function(err, categoryInfo){
if(err)
    next(err);
   else {
    res.json({status:"success", message: "Category updated successfully!!!", data:null});
   }
  });
 },
deleteById: function(req, res, next) {
    categoryModel.findByIdAndRemove(req.params.categoryId, function(err, categoryInfo){
   if(err)
    next(err);
   else {
    res.json({status:"success", message: "Category deleted successfully!!!", data:null});
   }
  });
 },
add: function(req, res, next) {
    categoryModel.create({ name: req.body.name }, function (err, result) {
      if (err) 
       next(err);
      else
       res.json({status: "success", message: "Category added successfully!!!", data: null});
      
    });
 },
}