const facilityModel = require('../models/facilities');
module.exports = {
 getById: function(req, res, next) {
  console.log(req.body);
  facilityModel.findById(req.params.facilityId, function(err, facilityInfo){
   if (err) {
    next(err);
   } else {
    res.json({status:"success", message: "facility found!!!", data:{facilities: facilityInfo}});
   }
  });
 },
getAll: function(req, res, next) {
  let facilitiesList = [];
  facilityModel.find({}, function(err, facilities){
   if (err){
    next(err);
   } else{
    for (let facility of facilities) {
      facilitiesList.push({id: facility._id, facilities_name: facility.facilities_name, facilities_details: facility.facilities_details, description: facility.description, released_on: facility.released_on});
    }
    res.json({status:"success", message: "facilities list found!!!", data:{facilities: facilitiesList}});
       
   }
});
 },
updateById: function(req, res, next) {
  facilityModel.findByIdAndUpdate(req.params.facilityId,{facilities_name:req.body.facilities_name},{facilities_details:req.body.facilities_details},{description:req.body.description}, function(err, facilityInfo){
if(err)
    next(err);
   else {
    res.json({status:"success", message: "facility updated successfully!!!", data:null});
   }
  });
 },
deleteById: function(req, res, next) {
  facilityModel.findByIdAndRemove(req.params.facilityId, function(err, facilityInfo){
   if(err)
    next(err);
   else {
    res.json({status:"success", message: "facility deleted successfully!!!", data:null});
   }
  });
 },
create: function(req, res, next) {
  facilityModel.create({ facilities_name: req.body.facilities_name, facilities_details: req.body.facilities_details, description:req.body.description, released_on: req.body.released_on }, function (err, result) {
      if (err) 
       next(err);
      else
       res.json({status: "success", message: "facility added successfully!!!", data: null});
      
    });
 },
}