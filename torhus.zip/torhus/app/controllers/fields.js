const User = require('../models/fields');
const Role = require('../models/facilities');

var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");

exports.field = (req, res) => {
  const field = new User({
    fieldName: req.body.fieldName,
    fieldDescription: req.body.fieldDescription,
    fieldReleased_on: req.body.fieldReleased_on
  });

  field.save((err, field) => {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }

    if (req.body.roles) {
        Role.find(
        {
            facilities_name: { $in: req.body.roles }
        },
        (err, roles) => {
          if (err) {
            res.status(500).send({ message: err });
            return;
          }

          field.roles = roles.map(role => role._id);
          field.save(err => {
            if (err) {
              res.status(500).send({ message: err });
              return;
            }

            res.send({ message: "field was added successfully!" });
          });
        }
      );
    } else {
        Role.findOne({ facilities_name: "Facility 1" }, (err, role) => {
          if (err) {
            res.status(500).send({ message: err });
            return;
          }
  
          field.roles = [role._id];
          field.save(err => {
            if (err) {
              res.status(500).send({ message: err });
              return;
            }
  
            res.send({ message: "field was added successfully!" });
          });
        });
      }
  });
};
exports.deleteById = (req, res) => {
  User.findByIdAndRemove(req.params.fieldId, function(err, facilityInfo){
   if(err)
    next(err);
   else {
    res.json({status:"success", message: "Field deleted successfully!!!", data:null});
   }
  });
 };
 exports.getAll = (req, res) => {
  let fieldList = [];
  User.find({}, function(err, fields){
   if (err){
    next(err);
   } else{
    for (let field of fields) {
      fieldList.push({id: field._id, fieldName: field.fieldName, fieldDescription: field.fieldDescription, fieldReleased_on: field.fieldReleased_on, roles: field.roles});
    }
    res.json({status:"success", message: "Fields list found!!!", data:{fields: fieldList}});
       
   }
});
 };