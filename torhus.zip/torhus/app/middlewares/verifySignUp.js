const db = require("../models");
const ROLES = db.ROLES;
require('dotenv'). config();
const User = db.user;
MAILGUN_APIKEY= '038474643a5443491178475015158c14-443ec20e-a3109603';
const mailgun = require("mailgun-js");
const DOMAIN = 'sandbox3cc2e8c76ce4482dbb63cf311ce30056.mailgun.org';
const mg = mailgun({apiKey: process.env.MAILGUN_APIKEY, domain: DOMAIN});

checkDuplicateUsernameOrEmail = (req, res, next) => {
  // Username
  const {fullname, username, email, password} = req.body;
    
  User.findOne({
    username: req.body.username
  }).exec((err, user) => {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }

    if (user) {
      res.status(400).send({ message: "Failed! Username is already in use!" });
      return;
    }

    // Email
    User.findOne({
      email: req.body.email
    }).exec((err, user) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }

      if (user) {
        res.status(400).send({ message: "Failed! Email is already in use!" });
        return;
      }
      const data = {
        
        from: 'noreply@hello.com',
        to: email,
        subject: 'Account Activation Link!!!',
        text: 'Testing some Mailgun awesomness!'
      };
      mg.messages().send(data, function (error, body) {
        console.log(body);
      });

      next();
    });
  });
};

checkRolesExisted = (req, res, next) => {
  if (req.body.roles) {
    for (let i = 0; i < req.body.roles.length; i++) {
      if (!ROLES.includes(req.body.roles[i])) {
        res.status(400).send({
          message: `Failed! Role ${req.body.roles[i]} does not exist!`
        });
        return;
      }
    }
  }

  next();
};

const verifySignUp = {
  checkDuplicateUsernameOrEmail,
  checkRolesExisted
};

module.exports = verifySignUp;